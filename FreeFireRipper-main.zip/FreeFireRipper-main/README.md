# Free Fire Ripper
**A Vm with pre-installed Free Fire and required tools for ripping Free fire 3d models using ninjaripper, on Android/Mac/Windows/Linux**

# ➡️ Features
1. Works on every device and every os ✅
2. No Pc required ❎
3. Automatically installed Free Fire with costume expansion pack 🤩
4. Ninjaripper and Noesis are pre-installed ☑️
5. Free Fire Automatically logged in ✔
6. 
# ➡️ Requirements 
1. GitHub Account 🔑
2. G-mail Account 📧
3. Any Browser on any device 🌐
4. Internet 🛜

# ➡️ Tutorial
https://www.youtube.com/watch?v=FlCx9gY3lWg

# ➡️ Important Note
1. Use of main free fire account is not recommended, I'm not responsible if you use it or get banned 🚫 
1. This repository is for personal use only only don't use it for illegal or inappropriate activities or your account will be banned. ⚠️
2. This repository is written and managed by me so you have no right to use this repo for commercial purposes. 👿
3. Contact me if you want to upload this repo's video on YT 📮

# ➡️ Contact

**Report issue [GitHub issues](https://github.com/inderxkang/Mixamo/issues)
Or Contact for help**

**[Instagram](https://www.instagram.com/inderx_kang)**

**[YouTube](https://youtube.com/@GW_KANG)**


